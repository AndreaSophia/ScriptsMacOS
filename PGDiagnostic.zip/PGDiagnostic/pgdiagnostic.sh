#!/bin/bash
# =============================================================================
# PGDiagnostic v1.0.0
# Herramienta de diagnóstico de conectividad PostgreSQL en macOS
# Apple Platform Team — Itaú
#
# Uso:
#   sudo bash pgdiagnostic.sh [--debug]
#
# Compatibilidad:
#   macOS Sonoma (14) | Sequoia (15) | Tahoe (16)
#   Apple Silicon (arm64) | Intel (x86_64)
#   bash 3.2+
# =============================================================================

[ -z "${BASH_VERSION:-}" ] && { echo "[ERROR] Requiere bash." >&2; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LIB_DIR="${SCRIPT_DIR}/lib"

# =============================================================================
# _load_modules — Carga los módulos en orden correcto
# =============================================================================
_load_modules() {
  local mods=(core collect_system collect_network collect_security
              diag_postgresql report)
  local m
  for m in "${mods[@]}"; do
    local f="${LIB_DIR}/${m}.sh"
    [ ! -f "$f" ] && { echo "[FATAL] Módulo no encontrado: $f" >&2; exit 1; }
    # shellcheck source=/dev/null
    source "$f"
  done
}

# =============================================================================
# _parse_args
# =============================================================================
_parse_args() {
  while [ $# -gt 0 ]; do
    case "$1" in
      --debug) export PGDIAG_DEBUG=1 ;;
      --help|-h) _help; exit 0 ;;
      *) ;;
    esac
    shift
  done
}

_help() {
  cat <<HELP
PGDiagnostic v1.0.0 — Apple Platform Team

USO:  sudo bash pgdiagnostic.sh [--debug]

Genera un diagnóstico completo de conectividad PostgreSQL en macOS.
Salida en: ~/Desktop/PGDiagnostic_<hostname>_<timestamp>/

HELP
}

# =============================================================================
# _preflight — Verificaciones mínimas antes de arrancar
# =============================================================================
_preflight() {
  require_root

  local ver major
  ver="$(get_macos_version)"
  major="$(echo "$ver" | cut -d. -f1)"
  [ "$major" -lt 14 ] 2>/dev/null && \
    log "WARN" "macOS $ver — recomendado 14 (Sonoma) o superior"

  log "OK" "macOS ${ver} | $(get_arch) | usuario: $(get_current_user)"
}

# =============================================================================
# _main_menu — Menú de selección de cliente
# =============================================================================
_main_menu() {
  printf "\n"
  sep
  printf "  ${C_WHITE}¿Qué cliente utiliza?${C_RST}\n"
  sep
  printf "\n"
  printf "  1) psql\n"
  printf "  2) DBeaver\n"
  printf "\n"
  printf "  Opción: "
  local c
  read -r c

  case "$c" in
    1|2)
      # Inicializar dirs y timeline DESPUÉS de que el usuario eligió
      init_dirs
      tl "Inicio PGDiagnostic v${PGDIAG_VERSION}"
      log "INFO" "Directorio de trabajo: ${OUTPUT_DIR}"
      diag_postgresql_with_choice "$c"
      ;;
    *)
      printf "\n  ${C_RED}Opción inválida.${C_RST}\n"
      _main_menu
      ;;
  esac
}

# =============================================================================
# diag_postgresql_with_choice — Despacha sin repetir el menú
# =============================================================================
diag_postgresql_with_choice() {
  case "$1" in
    1) CTX_CLIENT="psql";    _pg_flow_psql ;;
    2) CTX_CLIENT="dbeaver"; _pg_flow_dbeaver ;;
  esac
}

# =============================================================================
# Punto de entrada
# =============================================================================
main() {
  _load_modules
  _parse_args "$@"
  banner
  _preflight
  _main_menu
}

main "$@"
