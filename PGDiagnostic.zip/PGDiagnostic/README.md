# PGDiagnostic v1.0.0
**Herramienta de diagnóstico profesional para macOS — Equipo Apple, Itaú**

---

## ¿Qué hace?

PGDiagnostic recopila evidencias del sistema en un solo comando y genera un informe ejecutivo listo para adjuntar a un ticket de incidente. Cubre:

- **Sistema**: macOS, hardware, usuarios, FileVault, SIP, Secure Token
- **Red**: interfaces, DNS, proxies, rutas, conectividad, puertos, captura tcpdump
- **PostgreSQL**: estado, versión, configuración, logs, prueba de conexión, actividad
- **Workspace ONE**: enrollment MDM, perfiles, procesos, logs, restricciones
- **CrowdStrike Falcon**: estado del sensor, versión, System Extension, logs, impacto de red

**Salida:**
- Directorio de evidencias organizado en `/tmp/pgdiagnostic_<hostname>_<timestamp>/`
- Informe ejecutivo en TXT y HTML
- ZIP listo para adjuntar al incidente

---

## Compatibilidad

| macOS | Intel (x86_64) | Apple Silicon (arm64) |
|-------|:-:|:-:|
| Sonoma 14 | ✓ | ✓ |
| Sequoia 15 | ✓ | ✓ |
| Tahoe 16 | ✓ | ✓ |

Requiere bash 3.2+ (incluido en macOS por defecto).

---

## Uso rápido

```bash
# Diagnóstico completo
sudo bash pgdiagnostic.sh

# Sin captura de tráfico (más rápido)
sudo bash pgdiagnostic.sh --skip-tcpdump

# PostgreSQL en host remoto
sudo bash pgdiagnostic.sh --psql-host 10.0.0.5 --psql-port 5432

# Captura de 30 segundos, sin módulo CrowdStrike
sudo bash pgdiagnostic.sh --tcpdump-secs 30 --skip-cs

# Modo debug
sudo bash pgdiagnostic.sh --debug
```

---

## Opciones

| Opción | Default | Descripción |
|--------|---------|-------------|
| `--skip-tcpdump` | — | Omite captura de tráfico |
| `--skip-psql` | — | Omite módulo PostgreSQL |
| `--skip-ws1` | — | Omite módulo Workspace ONE |
| `--skip-cs` | — | Omite módulo CrowdStrike |
| `--tcpdump-secs N` | 15 | Duración de la captura |
| `--psql-host HOST` | localhost | Host PostgreSQL |
| `--psql-port PORT` | 5432 | Puerto PostgreSQL |
| `--psql-user USER` | postgres | Usuario PostgreSQL |
| `--debug` | — | Logs detallados |
| `--help` | — | Ayuda |

---

## Estructura del proyecto

```
PGDiagnostic/
├── pgdiagnostic.sh          ← Orquestador principal
├── lib/
│   ├── core.sh              ← Logging, utilidades, constantes
│   ├── system.sh            ← Sistema, hardware, macOS
│   ├── network.sh           ← Red, DNS, proxies, tcpdump
│   ├── postgresql.sh        ← Diagnóstico PostgreSQL
│   ├── workspace_one.sh     ← Workspace ONE / MDM
│   ├── crowdstrike.sh       ← CrowdStrike Falcon
│   └── report.sh            ← Informe ejecutivo y ZIP
└── README.md
```

---

## Estructura de la salida

```
/tmp/pgdiagnostic_<hostname>_<timestamp>/
├── pgdiagnostic.log
├── informe_ejecutivo.txt
├── informe_ejecutivo.html
└── evidencias/
    ├── sistema/
    │   ├── system_info.txt
    │   ├── processes_cpu.txt
    │   ├── filevault.txt
    │   ├── sip.txt
    │   └── secure_token.txt
    ├── red/
    │   ├── interfaces.txt
    │   ├── dns.txt
    │   ├── routes.txt
    │   ├── proxy.txt
    │   ├── connectivity.txt
    │   ├── open_ports.txt
    │   ├── wifi.txt
    │   ├── capture_<timestamp>.pcap
    │   └── tcpdump_summary.txt
    ├── postgresql/
    │   ├── pg_detection.txt
    │   ├── pg_version.txt
    │   ├── pg_config.txt
    │   ├── pg_hba.txt
    │   ├── pg_logs.txt
    │   ├── pg_connection_test.txt
    │   └── pg_activity.txt
    ├── workspace_one/
    │   ├── ws1_detection.txt
    │   ├── mdm_profiles.txt
    │   ├── mdm_enrollment.txt
    │   ├── ws1_processes.txt
    │   ├── ws1_logs.txt
    │   └── mdm_restrictions.txt
    └── crowdstrike/
        ├── cs_detection.txt
        ├── cs_status.txt
        ├── cs_version.txt
        ├── cs_processes.txt
        ├── cs_sysext.txt
        ├── cs_logs.txt
        └── cs_network_impact.txt

/tmp/PGDiagnostic_<hostname>_<timestamp>.zip  ← listo para adjuntar
```

---

## Permisos requeridos

Se necesita `sudo` para:
- `tcpdump` (captura de tráfico)
- `sysadminctl` (Secure Token)
- `profiles` (perfiles MDM)
- `fdesetup` (FileVault)
- Acceso a logs del sistema

---

## Seguridad

- El script **no transmite datos** fuera del equipo.
- El ZIP se genera localmente en `/tmp/`.
- Las contraseñas nunca se recopilan ni almacenan.
- Los archivos `.pcap` contienen tráfico de red — manejar con cuidado.
