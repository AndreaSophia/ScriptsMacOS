#!/bin/bash
# =============================================================================
# PGDiagnostic — lib/collect_network.sh
# Responsabilidad: interfaces, DNS, gateway, routing, VPN, herramientas de red
# Popula: CTX_IP, CTX_VPN_STATUS, CTX_VPN_IFACE, CTX_INTERFACE,
#         CTX_GATEWAY, CTX_DNS_SERVERS, CTX_TCP_5432
# =============================================================================

# =============================================================================
# collect_network — Punto de entrada del módulo de red
# Retorna: RC_OK | RC_WARN
# =============================================================================
collect_network() {
  log "STEP" "Información de red"
  tl "Red"

  _collect_interfaces
  _collect_dns
  _collect_gateway_routing
  _collect_network_tools

  return $RC_OK
}

# =============================================================================
# _collect_interfaces — Interfaces de red activas y estado
# =============================================================================
_collect_interfaces() {
  log "INFO" "Interfaces de red"
  local outfile="${EVIDENCE_DIR}/red/interfaces.txt"

  {
    printf '# ======================================================\n'
    printf '# INTERFACES DE RED\n'
    printf '# Generado: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    printf '# ======================================================\n\n'
  } > "$outfile"

  run_collect "ifconfig -a" "$outfile" ifconfig -a
  run_collect "networksetup -listallhardwareports" "$outfile" \
    networksetup -listallhardwareports
  run_collect "netstat -i (estadísticas)" "$outfile" netstat -i

  # --- IP activa principal ---
  # Probar en orden: en0, en1, en2, en3, luego cualquier interfaz activa
  local ip="" iface
  for iface in en0 en1 en2 en3; do
    ip="$(ipconfig getifaddr "$iface" 2>/dev/null)"
    [ -n "$ip" ] && break
  done
  # Fallback: primera IP no loopback reportada por ifconfig
  if [ -z "$ip" ]; then
    ip="$(ifconfig 2>/dev/null | awk '/inet / && !/127\.0\.0\.1/ {print $2; exit}')"
  fi
  CTX_IP="${ip:-No detectada}"

  # --- Detectar VPN (interfaces utun con IP asignada) ---
  local vpn_iface="" vpn_ip="" iface_name
  while IFS= read -r iface_name; do
    vpn_ip="$(ipconfig getifaddr "$iface_name" 2>/dev/null)"
    if [ -n "$vpn_ip" ]; then
      vpn_iface="$iface_name"
      break
    fi
  done < <(ifconfig 2>/dev/null | awk -F: '/^utun[0-9]+:/{print $1}')

  if [ -n "$vpn_iface" ]; then
    CTX_VPN_STATUS="Activa"
    CTX_VPN_IFACE="${vpn_iface} (${vpn_ip})"
    log "WARN" "VPN activa: ${CTX_VPN_IFACE}"
    record "VPN" "$RC_WARN" "Activa en ${CTX_VPN_IFACE} — puede afectar diagnóstico"
  else
    CTX_VPN_STATUS="No detectada"
    CTX_VPN_IFACE=""
    record "VPN" "$RC_OK" "Sin VPN activa"
  fi

  log "OK" "IP: ${CTX_IP} | VPN: ${CTX_VPN_STATUS}"
  record "Red - IP origen" "$RC_OK" "$CTX_IP"
  tl "Interfaces (IP: ${CTX_IP}, VPN: ${CTX_VPN_STATUS})"
}

# =============================================================================
# _collect_dns — Servidores DNS y resolución
# =============================================================================
_collect_dns() {
  log "INFO" "DNS"
  local outfile="${EVIDENCE_DIR}/red/dns.txt"
  tl "DNS"

  {
    printf '# ======================================================\n'
    printf '# DNS\n'
    printf '# Generado: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    printf '# ======================================================\n\n'
  } > "$outfile"

  run_collect "scutil --dns" "$outfile" scutil --dns

  # dig
  if check_bin dig; then
    run_collect_timeout 8 "dig google.com" "$outfile" \
      dig google.com +short +time=5
    run_collect_timeout 8 "dig version.postgresql.org" "$outfile" \
      dig version.postgresql.org +short +time=5
  fi

  # host
  if check_bin host; then
    run_collect_timeout 8 "host google.com" "$outfile" \
      host -W 5 google.com
  fi

  # nslookup
  if check_bin nslookup; then
    run_collect_timeout 8 "nslookup google.com" "$outfile" \
      nslookup google.com
  fi

  # Extraer servidores DNS activos.
  # scutil --dns produce líneas del tipo: "  nameserver[0] : 8.8.8.8"
  # El grep original falla si hay espacios variables; usar awk en su lugar.
  CTX_DNS_SERVERS="$(scutil --dns 2>/dev/null | \
    awk '/nameserver\[/{print $NF}' | \
    sort -u | head -4 | tr '\n' ' ' | xargs)"

  # Fallback: leer resolv.conf si scutil no devuelve nada
  if [ -z "$CTX_DNS_SERVERS" ] && [ -f /etc/resolv.conf ]; then
    CTX_DNS_SERVERS="$(awk '/^nameserver/{print $2}' /etc/resolv.conf | \
      head -4 | tr '\n' ' ' | xargs)"
  fi

  if [ -n "$CTX_DNS_SERVERS" ]; then
    log "OK" "DNS: ${CTX_DNS_SERVERS}"
    record "DNS" "$RC_OK" "$CTX_DNS_SERVERS"
  else
    log "WARN" "No se detectaron servidores DNS"
    record "DNS" "$RC_WARN" "Sin servidores DNS detectados"
  fi
  tl "DNS (${CTX_DNS_SERVERS:-sin datos})"
}

# =============================================================================
# _collect_gateway_routing — Gateway, tabla de rutas
# =============================================================================
_collect_gateway_routing() {
  log "INFO" "Gateway y routing"
  local outfile="${EVIDENCE_DIR}/red/routing.txt"
  tl "Routing"

  {
    printf '# ======================================================\n'
    printf '# GATEWAY Y ROUTING\n'
    printf '# Generado: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    printf '# ======================================================\n\n'
  } > "$outfile"

  run_collect "route -n get default" "$outfile" route -n get default
  run_collect "netstat -rn" "$outfile" netstat -rn

  # Extraer gateway — la salida de route -n get default tiene formato:
  #   "   gateway: 192.168.1.1"  (con espacios variables al inicio)
  # Usar awk para robustez en lugar de grep+awk.
  CTX_GATEWAY="$(route -n get default 2>/dev/null | \
    awk '/[[:space:]]*gateway:/{print $NF}' | head -1)"
  CTX_GATEWAY="${CTX_GATEWAY:-No detectado}"

  log "OK" "Gateway: ${CTX_GATEWAY}"
  record "Red - Gateway" "$RC_OK" "$CTX_GATEWAY"
  tl "Gateway (${CTX_GATEWAY})"
}

# =============================================================================
# detect_route_to_host <host>
# Detecta la interfaz exacta para llegar al host PostgreSQL con route get.
# NO asume en0 ni utun. Popula CTX_INTERFACE.
# =============================================================================
detect_route_to_host() {
  local host="$1"
  local outfile="${EVIDENCE_DIR}/red/route_to_psql.txt"

  log "INFO" "Detectando interfaz hacia ${host}"
  tl "Routing hacia ${host}"

  {
    printf '# ======================================================\n'
    printf '# RUTA HACIA HOST POSTGRESQL\n'
    printf '# Host: %s\n' "$host"
    printf '# Generado: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    printf '# ======================================================\n\n'

    printf '# route -n get %s\n# ---\n' "$host"
    route -n get "$host" 2>&1
    printf '\n'

    printf '# traceroute -m 8 -w 2 %s\n# ---\n' "$host"
    timeout 20 traceroute -m 8 -w 2 "$host" 2>&1 || echo "traceroute no completado"
    printf '\n'

  } > "$outfile"

  # Extraer interfaz desde route get
  local iface
  iface="$(route -n get "$host" 2>/dev/null | \
    grep '^\s*interface:' | awk '{print $2}' | head -1)"

  if [ -z "$iface" ]; then
    # Fallback: interfaz del gateway por defecto
    iface="$(route -n get default 2>/dev/null | \
      grep '^\s*interface:' | awk '{print $2}' | head -1)"
    iface="${iface:-en0}"
    log "WARN" "No se pudo determinar interfaz específica → fallback: $iface"
    record "Interfaz hacia PG" "$RC_WARN" "$iface (fallback)"
  else
    log "OK" "Interfaz hacia ${host}: ${iface}"
    record "Interfaz hacia PG" "$RC_OK" "$iface"
  fi

  CTX_INTERFACE="$iface"
  tl "Interfaz hacia PG: ${iface}"

  # Resolver host si es nombre (no IP)
  if echo "$host" | grep -qvE '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$'; then
    local resolved
    resolved="$(dig +short "$host" 2>/dev/null | head -1 || \
                nslookup "$host" 2>/dev/null | grep 'Address:' | tail -1 | awk '{print $2}')"
    if [ -n "$resolved" ]; then
      log "OK" "DNS ${host} → ${resolved}"
      {
        printf '# DNS resolution\n# ---\n'
        printf '%s → %s\n\n' "$host" "$resolved"
      } >> "$outfile"
      record "DNS - Host PG" "$RC_OK" "${host} → ${resolved}"
    else
      log "WARN" "No se pudo resolver ${host}"
      record "DNS - Host PG" "$RC_WARN" "No resuelto: ${host}"
    fi
    tl "DNS host PG (${resolved:-no resuelto})"
  fi
}

# =============================================================================
# check_tcp_port <host> <puerto>
# Verifica conectividad TCP. Popula CTX_TCP_5432.
# Retorna RC_OK | RC_ERROR
# =============================================================================
check_tcp_port() {
  local host="$1"
  local port="$2"
  local outfile="${EVIDENCE_DIR}/red/tcp_port_check.txt"

  log "INFO" "Test TCP ${host}:${port}"
  tl "TCP Test ${port}"

  {
    printf '# ======================================================\n'
    printf '# TEST CONECTIVIDAD TCP\n'
    printf '# Host: %s  Puerto: %s\n' "$host" "$port"
    printf '# Generado: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    printf '# ======================================================\n\n'

    printf '# nc -zv -w 5 %s %s\n# ---\n' "$host" "$port"
    nc -zv -w 5 "$host" "$port" 2>&1
    printf 'rc: %d\n\n' "$?"
  } > "$outfile"

  if nc -zw 5 "$host" "$port" 2>/dev/null; then
    CTX_TCP_5432="Abierto"
    log "OK" "TCP ${host}:${port} → ABIERTO"
    tl "TCP ${port} OK"
    record "TCP :${port}" "$RC_OK" "Puerto alcanzable"
    return $RC_OK
  else
    CTX_TCP_5432="Cerrado / no alcanzable"
    log "ERROR" "TCP ${host}:${port} → NO ALCANZABLE"
    tl "TCP ${port} FALLO"
    record "TCP :${port}" "$RC_ERROR" "Puerto no alcanzable"
    return $RC_ERROR
  fi
}

# =============================================================================
# _collect_network_tools — dig, host, nslookup, arp, lsof, netstat adicional
# =============================================================================
_collect_network_tools() {
  log "INFO" "Herramientas de red complementarias"
  local outfile="${EVIDENCE_DIR}/red/network_tools.txt"

  {
    printf '# ======================================================\n'
    printf '# HERRAMIENTAS DE RED\n'
    printf '# Generado: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    printf '# ======================================================\n\n'
  } > "$outfile"

  # ARP table
  run_collect "arp -a (tabla ARP)" "$outfile" arp -a

  # Conexiones TCP establecidas
  run_collect "netstat -an (TCP establecidas)" "$outfile" \
    netstat -an -p tcp

  # lsof conexiones de red activas
  if check_bin lsof; then
    run_collect "lsof -i TCP (conexiones activas)" "$outfile" \
      lsof -iTCP -sTCP:ESTABLISHED -n -P
  fi

  # Proxy del sistema
  run_collect "scutil --proxy" "$outfile" scutil --proxy

  # Estado de red (scutil --nwi)
  run_collect "scutil --nwi (estado de red)" "$outfile" scutil --nwi

  log "OK" "Herramientas de red recopiladas"
}
