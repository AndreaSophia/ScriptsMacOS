#!/bin/bash
# =============================================================================
# PGDiagnostic — lib/collect_security.sh
# Responsabilidad: estado de Workspace ONE (MDM) y CrowdStrike Falcon
# Popula: CTX_WS1_STATUS, CTX_CS_STATUS
# =============================================================================

# Rutas conocidas de Workspace ONE Hub
readonly _WS1_APP_PATHS=(
  "/Applications/Workspace ONE Intelligent Hub.app"
  "/Applications/VMware Workspace ONE.app"
  "/Applications/Intelligent Hub.app"
)

# Rutas conocidas de falconctl
readonly _CS_FALCONCTL_PATHS=(
  "/Applications/Falcon.app/Contents/Resources/falconctl"
  "/opt/CrowdStrike/falconctl"
  "/usr/local/bin/falconctl"
)

# Rutas conocidas de Falcon.app
readonly _CS_APP_PATHS=(
  "/Applications/Falcon.app"
  "/Applications/CrowdStrike Falcon.app"
)

# =============================================================================
# collect_workspace_one — Estado MDM y Workspace ONE
# Popula CTX_WS1_STATUS
# Retorna: RC_OK | RC_WARN | RC_ERROR
# =============================================================================
collect_workspace_one() {
  log "STEP" "Workspace ONE"
  tl "Workspace ONE"

  local outfile="${EVIDENCE_DIR}/workspace_one/ws1_status.txt"

  {
    printf '# ======================================================\n'
    printf '# WORKSPACE ONE (UEM)\n'
    printf '# Generado: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    printf '# ======================================================\n\n'
  } > "$outfile"

  # --- Detectar Hub instalado ---
  local ws1_app="" ws1_ver=""
  local app
  for app in "${_WS1_APP_PATHS[@]}"; do
    if [ -d "$app" ]; then
      ws1_app="$app"
      ws1_ver="$(defaults read "${app}/Contents/Info" \
        CFBundleShortVersionString 2>/dev/null || echo 'N/A')"
      break
    fi
  done

  {
    printf '# App instalada\n# ---\n%s\n' "${ws1_app:-No encontrada}"
    [ -n "$ws1_ver" ] && printf 'Versión: %s\n' "$ws1_ver"
    printf '\n'
  } >> "$outfile"

  # --- Enrollment MDM ---
  run_collect "profiles status -type enrollment" "$outfile" \
    profiles status -type enrollment

  # --- Perfiles instalados ---
  run_collect "profiles list -all" "$outfile" \
    profiles list -all

  # --- Supervisión ---
  {
    printf '# Estado supervisión\n# ---\n'
    profiles status -type supervising 2>/dev/null || echo "N/A"
    printf '\n'
  } >> "$outfile"

  # --- LaunchDaemons ---
  {
    printf '# LaunchDaemons WS1\n# ---\n'
    launchctl list 2>/dev/null | \
      grep -iE "airwatch|workspace|hub|vmware|mdm" || echo "Ninguno"
    printf '\n'
  } >> "$outfile"

  # --- Procesos ---
  {
    printf '# Procesos WS1\n# ---\n'
    ps aux 2>/dev/null | \
      grep -iE "[H]ub|[A]irWatch|[I]ntelligent|[W]orkspace" || echo "Ninguno"
    printf '\n'
  } >> "$outfile"

  # --- Logs MDM recientes ---
  run_collect_timeout 10 "Logs mdmclient (últimas 2h)" "$outfile" \
    log show \
      --predicate 'process == "mdmclient"' \
      --last 2h --style compact

  # --- UDID del dispositivo ---
  local udid
  udid="$(system_profiler SPHardwareDataType 2>/dev/null | \
    grep 'Provisioning UDID' | awk -F': ' '{print $2}' | xargs || \
    ioreg -d2 -c IOPlatformExpertDevice 2>/dev/null | \
    grep IOPlatformUUID | awk -F'"' '{print $4}')"
  {
    printf '# UDID del dispositivo\n# ---\n%s\n\n' "${udid:-No detectado}"
  } >> "$outfile"

  # --- Managed Preferences ---
  {
    printf '# Managed Preferences instaladas\n# ---\n'
    ls /Library/Managed\ Preferences/ 2>/dev/null || echo "Ninguna"
    printf '\n'
  } >> "$outfile"

  # --- Determinar estado ---
  local enrollment_output
  enrollment_output="$(profiles status -type enrollment 2>/dev/null)"
  local rc=$RC_WARN

  if [ -n "$ws1_app" ] && echo "$enrollment_output" | grep -qi "enrolled"; then
    CTX_WS1_STATUS="Instalado y enrollado (v${ws1_ver})"
    rc=$RC_OK
  elif echo "$enrollment_output" | grep -qi "enrolled"; then
    CTX_WS1_STATUS="Enrollado (Hub no detectado)"
    rc=$RC_OK
  elif [ -n "$ws1_app" ]; then
    CTX_WS1_STATUS="Instalado pero no enrollado (v${ws1_ver})"
    rc=$RC_WARN
  else
    CTX_WS1_STATUS="No detectado"
    rc=$RC_ERROR
  fi

  log "OK" "Workspace ONE: ${CTX_WS1_STATUS}"
  record "Workspace ONE" "$rc" "$CTX_WS1_STATUS"
  tl "Workspace ONE: ${CTX_WS1_STATUS}"
  return $rc
}

# =============================================================================
# collect_crowdstrike — Estado del sensor CrowdStrike Falcon
# Popula CTX_CS_STATUS
# Retorna: RC_OK | RC_WARN | RC_ERROR
# =============================================================================
collect_crowdstrike() {
  log "STEP" "CrowdStrike Falcon"
  tl "CrowdStrike"

  local outfile="${EVIDENCE_DIR}/crowdstrike/cs_status.txt"

  {
    printf '# ======================================================\n'
    printf '# CROWDSTRIKE FALCON\n'
    printf '# Generado: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    printf '# ======================================================\n\n'
  } > "$outfile"

  # --- Buscar falconctl ---
  local falconctl=""
  local p
  for p in "${_CS_FALCONCTL_PATHS[@]}"; do
    [ -x "$p" ] && { falconctl="$p"; break; }
  done
  [ -z "$falconctl" ] && check_bin falconctl && falconctl="falconctl"

  # --- Detectar app ---
  local cs_app="" cs_ver=""
  local app
  for app in "${_CS_APP_PATHS[@]}"; do
    if [ -d "$app" ]; then
      cs_app="$app"
      cs_ver="$(defaults read "${app}/Contents/Info" \
        CFBundleShortVersionString 2>/dev/null || echo 'N/A')"
      break
    fi
  done

  {
    printf '# App instalada\n# ---\n%s\n' "${cs_app:-No encontrada}"
    [ -n "$cs_ver" ] && printf 'Versión bundle: %s\n' "$cs_ver"
    printf 'falconctl: %s\n\n' "${falconctl:-No encontrado}"
  } >> "$outfile"

  # --- falconctl stats ---
  local sensor_stats=""
  if [ -n "$falconctl" ]; then
    sensor_stats="$("$falconctl" stats 2>/dev/null || true)"
    {
      printf '# falconctl stats\n# ---\n'
      echo "$sensor_stats"
      printf '\n'
    } >> "$outfile"

    {
      printf '# falconctl stats agent_info\n# ---\n'
      "$falconctl" stats agent_info 2>&1 || echo "N/A"
      printf '\n'
    } >> "$outfile"
  fi

  # --- System Extension ---
  {
    printf '# System Extensions Falcon\n# ---\n'
    systemextensionsctl list 2>/dev/null | \
      grep -iE "crowdstrike|falcon" || echo "Ninguna"
    printf '\n'
  } >> "$outfile"

  # --- Procesos ---
  {
    printf '# Procesos Falcon\n# ---\n'
    ps aux 2>/dev/null | \
      grep -iE "[F]alcon|[C]rowdstrike|[c]ssensor" || echo "Ninguno"
    printf '\n'
  } >> "$outfile"

  # --- LaunchDaemons ---
  {
    printf '# LaunchDaemons CrowdStrike\n# ---\n'
    launchctl list 2>/dev/null | \
      grep -iE "crowdstrike|falcon" || echo "Ninguno"
    printf '\n'
  } >> "$outfile"

  # --- Logs recientes ---
  run_collect_timeout 10 "Logs Falcon (últimas 2h)" "$outfile" \
    log show \
      --predicate 'process CONTAINS[c] "falcon" OR process CONTAINS[c] "CrowdStrike"' \
      --last 2h --style compact

  # --- Determinar estado ---
  local rc=$RC_WARN

  if [ -n "$sensor_stats" ]; then
    if echo "$sensor_stats" | grep -qiE "State=connected|Sensor operational|Running"; then
      CTX_CS_STATUS="Operativo (v${cs_ver})"
      rc=$RC_OK
    elif echo "$sensor_stats" | grep -qiE "RFM|Reduced Functionality"; then
      CTX_CS_STATUS="Modo RFM — funcionalidad reducida (v${cs_ver})"
      rc=$RC_WARN
    else
      local raw_state
      raw_state="$(echo "$sensor_stats" | grep 'State=' | head -1 | tr -d ' ')"
      CTX_CS_STATUS="${raw_state:-Estado indeterminado} (v${cs_ver})"
      rc=$RC_WARN
    fi
  elif [ -z "$cs_app" ] && [ -z "$falconctl" ]; then
    CTX_CS_STATUS="No instalado"
    rc=$RC_ERROR
  else
    local falcon_pid
    falcon_pid="$(pgrep -i falcon 2>/dev/null | head -1)"
    if [ -n "$falcon_pid" ]; then
      CTX_CS_STATUS="Proceso corriendo, stats no disponibles (v${cs_ver})"
      rc=$RC_WARN
    else
      CTX_CS_STATUS="Instalado pero no corriendo (v${cs_ver})"
      rc=$RC_ERROR
    fi
  fi

  log "OK" "CrowdStrike: ${CTX_CS_STATUS}"
  record "CrowdStrike" "$rc" "$CTX_CS_STATUS"
  tl "CrowdStrike: ${CTX_CS_STATUS}"
  return $rc
}
