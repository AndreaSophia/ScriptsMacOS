#!/bin/bash
# =============================================================================
# PGDiagnostic — lib/report.sh
# Responsabilidad: Executive_Report.txt, Executive_Report.html,
#   finalizar Timeline y crear ZIP final
# =============================================================================

# =============================================================================
# generate_report — Punto de entrada
# =============================================================================
generate_report() {
  log "STEP" "Generando informe ejecutivo"
  tl "Reporte"

  _report_txt
  _report_html
  _finalize_timeline
  _create_zip
  _print_summary
}

# =============================================================================
# _rc_label <rc> — Convierte RC_* a texto
# =============================================================================
_rc_label() {
  case "$1" in
    0) echo "PASÓ" ;;
    1) echo "ADVERTENCIA" ;;
    2) echo "FALLÓ" ;;
    3) echo "OMITIDO" ;;
    *) echo "DESCONOCIDO" ;;
  esac
}

# =============================================================================
# _classification_block_txt — Bloque de conclusión en texto
# =============================================================================
_classification_block_txt() {
  case "$CTX_CLASSIFICATION" in
    green)  echo "🟢  Problema no reproducido" ;;
    yellow) echo "🟡  Problema reproducido con evidencia insuficiente" ;;
    red)    echo "🔴  Problema reproducido con evidencia sólida" ;;
    *)      echo "⚪  Clasificación no disponible" ;;
  esac
}

# =============================================================================
# _report_txt — Genera Executive_Report.txt
# =============================================================================
_report_txt() {
  local serial
  serial="$(system_profiler SPHardwareDataType 2>/dev/null | \
    awk -F': ' '/Serial Number/{gsub(/^[[:space:]]+/,"",$2); print $2; exit}' || echo 'N/A')"
  [ -z "$serial" ] && serial="N/A"

  {
    printf '=============================================================\n'
    printf '  PGDiagnostic — Executive Report\n'
    printf '  %s  |  v%s\n' "$PGDIAG_ORG" "$PGDIAG_VERSION"
    printf '=============================================================\n\n'
    printf '  Generado  : %s\n\n' "$PGDIAG_DATE_HUMAN"

    printf '-------------------------------------------------------------\n'
    printf '  EQUIPO\n'
    printf '-------------------------------------------------------------\n'
    printf '  Equipo          : %s\n' "${CTX_MAC_MODEL:-N/A}"
    printf '  Serial          : %s\n' "$serial"
    printf '  macOS           : %s\n' "${CTX_MACOS_VER:-N/A}"
    printf '  Arquitectura    : %s\n' "${CTX_ARCH:-N/A}"
    printf '  Usuario         : %s\n' "${CTX_CURRENT_USER:-N/A}"
    printf '  Hostname        : %s\n' "${CTX_HOSTNAME_DISPLAY:-$PGDIAG_HOSTNAME}"
    printf '\n'

    printf '-------------------------------------------------------------\n'
    printf '  RED\n'
    printf '-------------------------------------------------------------\n'
    printf '  IP origen       : %s\n' "${CTX_IP:-N/A}"
    printf '  VPN             : %s\n' "${CTX_VPN_STATUS:-N/A}"
    printf '  Interfaz        : %s\n' "${CTX_INTERFACE:-N/A}"
    printf '  Gateway         : %s\n' "${CTX_GATEWAY:-N/A}"
    printf '  DNS             : %s\n\n' "${CTX_DNS_SERVERS:-N/A}"
    printf '-------------------------------------------------------------\n'
    printf '  POSTGRESQL\n'
    printf '-------------------------------------------------------------\n'
    printf '  Cliente         : %s\n' "${CTX_CLIENT:-N/A}"
    printf '  Servidor        : %s:%s\n' "${CTX_PSQL_HOST:-N/A}" "${CTX_PSQL_PORT:-5432}"
    printf '  Usuario DB      : %s\n' "${CTX_PSQL_USER:-N/A}"
    printf '  Base de datos   : %s\n' "${CTX_PSQL_DB:-N/A}"
    printf '  Versión server  : %s\n' "${CTX_PSQL_SERVER_VER:-N/A}"
    printf '  Puerto %s      : %s\n' "${CTX_PSQL_PORT:-5432}" "${CTX_TCP_5432:-N/A}"
    printf '  Resultado TCP   : %s\n' "${CTX_TCP_5432:-N/A}"
    printf '  Resultado PG    : %s\n' "${CTX_PSQL_RESULT:-N/A}"
    printf '  Tiempo conexión : %s\n\n' "${CTX_PSQL_TIME:-N/A}"

    printf '-------------------------------------------------------------\n'
    printf '  SEGURIDAD\n'
    printf '-------------------------------------------------------------\n'
    printf '  Workspace ONE   : %s\n' "${CTX_WS1_STATUS:-N/A}"
    printf '  CrowdStrike     : %s\n\n' "${CTX_CS_STATUS:-N/A}"

    printf '-------------------------------------------------------------\n'
    printf '  ESTADO DE PRUEBAS\n'
    printf '-------------------------------------------------------------\n'
    printf '  %-38s %-14s %s\n' "MÓDULO" "ESTADO" "DETALLE"
    printf '  %-38s %-14s %s\n' \
      "$(printf '%0.s─' $(seq 1 38))" \
      "$(printf '%0.s─' $(seq 1 14))" \
      "$(printf '%0.s─' $(seq 1 35))"

    local line
    while IFS= read -r line; do
      [ -z "$line" ] && continue
      local s rc d label
      s="$(echo "$line" | cut -d'|' -f1)"
      rc="$(echo "$line" | cut -d'|' -f4)"
      d="$(echo "$line" | cut -d'|' -f7)"
      label="$(_rc_label "$rc")"
      printf '  %-38s %-14s %s\n' "$s" "$label" "$d"
    done < <(printf "%b" "$MODULE_RESULTS")

    printf '\n'
    printf '-------------------------------------------------------------\n'
    printf '  CONCLUSIÓN\n'
    printf '-------------------------------------------------------------\n'
    printf '  %s\n\n' "$(_classification_block_txt)"

    printf '-------------------------------------------------------------\n'
    printf '  HIPÓTESIS (ordenadas por probabilidad)\n'
    printf '-------------------------------------------------------------\n'
    printf '  NOTA: Estas hipótesis se derivan exclusivamente de la\n'
    printf '  evidencia recopilada. No representan una causa confirmada.\n\n'
    printf "%b" "$PSQL_HYPOTHESES" | while IFS= read -r h; do
      [ -z "$h" ] && continue
      printf '  %s\n' "$h"
    done

    printf '\n'
    printf '-------------------------------------------------------------\n'
    printf '  ARCHIVOS GENERADOS\n'
    printf '-------------------------------------------------------------\n'
    find "$OUTPUT_DIR" -type f | sort | while IFS= read -r f; do
      local rel sz
      rel="${f#$OUTPUT_DIR/}"
      sz="$(du -sh "$f" 2>/dev/null | awk '{print $1}')"
      printf '  %-58s %s\n' "$rel" "$sz"
    done

    printf '\n=============================================================\n'
    printf '  PGDiagnostic v%s — %s\n' "$PGDIAG_VERSION" "$PGDIAG_ORG"
    printf '=============================================================\n'

  } > "$REPORT_TXT"

  log "OK" "Executive_Report.txt generado"
  tl "Executive_Report.txt"
}

# =============================================================================
# _report_html — Genera Executive_Report.html
# =============================================================================
_report_html() {
  local serial
  serial="$(system_profiler SPHardwareDataType 2>/dev/null | \
    awk -F': ' '/Serial Number/{gsub(/^[[:space:]]+/,"",$2); print $2; exit}')"
  [ -z "$serial" ] && serial="N/A"

  # Color de clasificación
  local cls_color cls_icon cls_text
  case "$CTX_CLASSIFICATION" in
    green)
      cls_color="#4caf50"; cls_icon="🟢"
      cls_text="Problema no reproducido" ;;
    yellow)
      cls_color="#ffc107"; cls_icon="🟡"
      cls_text="Problema reproducido con evidencia insuficiente" ;;
    red)
      cls_color="#f44336"; cls_icon="🔴"
      cls_text="Problema reproducido con evidencia sólida" ;;
    *)
      cls_color="#888"; cls_icon="⚪"
      cls_text="Clasificación no disponible" ;;
  esac

  # Escape helper inline
  _esc() { echo "$1" | sed 's/&/\&amp;/g;s/</\&lt;/g;s/>/\&gt;/g'; }

  cat > "$REPORT_HTML" <<HTMLHEAD
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PGDiagnostic — Executive Report</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'SF Pro Text','Segoe UI',sans-serif;
  background:#0d0d0d;color:#d0d0d0;padding:36px 28px;font-size:13px;
  line-height:1.65;max-width:1060px;margin:0 auto}
.hdr{border-left:3px solid #0ff;padding:14px 20px;margin-bottom:30px;
  background:#141414;border-radius:0 6px 6px 0}
.hdr h1{font-size:19px;color:#0ff;font-weight:700;letter-spacing:.4px}
.hdr .sub{color:#555;font-size:11px;margin-top:3px}
h2{font-size:10px;color:#0ff;text-transform:uppercase;letter-spacing:1.5px;
  margin:26px 0 10px;padding-bottom:5px;border-bottom:1px solid #1e1e1e}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));
  gap:9px;margin-bottom:28px}
.card{background:#141414;border:1px solid #1e1e1e;border-radius:5px;padding:10px 14px}
.card .lbl{font-size:9px;color:#555;text-transform:uppercase;letter-spacing:.5px}
.card .val{font-size:14px;color:#e0e0e0;font-weight:600;margin-top:2px}
.itbl{width:100%;border-collapse:collapse;margin-bottom:18px}
.itbl td{padding:6px 10px;border-bottom:1px solid #181818;vertical-align:top}
.itbl td:first-child{color:#555;width:190px;font-size:11px}
.itbl td:last-child{color:#ccc;font-weight:500}
table.res{width:100%;border-collapse:collapse;margin-bottom:18px}
table.res th{text-align:left;font-size:9px;color:#444;text-transform:uppercase;
  letter-spacing:.5px;padding:5px 9px;border-bottom:1px solid #1e1e1e}
table.res td{padding:7px 9px;border-bottom:1px solid #171717;vertical-align:top}
table.res tr:hover td{background:#141414}
.badge{display:inline-block;padding:2px 8px;border-radius:9px;font-size:9px;
  font-weight:700;letter-spacing:.4px;text-transform:uppercase}
.ok   {background:#0d2e1a;color:#4caf50;border:1px solid #1a5c30}
.warn {background:#2e2400;color:#ffc107;border:1px solid #5c4a00}
.err  {background:#2e0d0d;color:#f44336;border:1px solid #5c1a1a}
.skip {background:#1e1e1e;color:#666;border:1px solid #333}
.cls-box{background:#111;border:1px solid #1e1e1e;border-radius:6px;
  padding:14px 18px;margin-bottom:18px;font-size:16px;font-weight:700}
.hyp-box{background:#111;border:1px solid #1e1e1e;border-radius:6px;
  padding:14px 18px;margin-bottom:18px}
.hyp-note{font-size:11px;color:#444;margin-bottom:10px;padding:5px 9px;
  background:#0d0d0d;border-left:2px solid #333;border-radius:0 3px 3px 0}
.hyp-box ol{padding-left:18px}.hyp-box li{margin:5px 0;color:#999}
.hyp-box li::marker{color:#0ff}
.footer{margin-top:36px;padding-top:12px;border-top:1px solid #1e1e1e;
  color:#333;font-size:10px;text-align:center}
</style>
</head>
<body>
HTMLHEAD

  cat >> "$REPORT_HTML" <<HTMLBODY
<div class="hdr">
  <h1>PGDiagnostic &mdash; Executive Report</h1>
  <div class="sub">$(_esc "$PGDIAG_ORG") &nbsp;·&nbsp; v${PGDIAG_VERSION} &nbsp;·&nbsp; $(_esc "$PGDIAG_DATE_HUMAN")</div>
</div>

<div class="grid">
  <div class="card"><div class="lbl">Hostname</div><div class="val">$(_esc "${CTX_HOSTNAME_DISPLAY:-$PGDIAG_HOSTNAME}")</div></div>
  <div class="card"><div class="lbl">macOS</div><div class="val">$(_esc "${CTX_MACOS_VER:-N/A}")</div></div>
  <div class="card"><div class="lbl">Arquitectura</div><div class="val">$(_esc "${CTX_ARCH:-N/A}")</div></div>
  <div class="card"><div class="lbl">Usuario</div><div class="val">$(_esc "${CTX_CURRENT_USER:-N/A}")</div></div>
  <div class="card"><div class="lbl">IP</div><div class="val">$(_esc "${CTX_IP:-N/A}")</div></div>
  <div class="card"><div class="lbl">VPN</div><div class="val">$(_esc "${CTX_VPN_STATUS:-N/A}")</div></div>
</div>

<h2>Equipo</h2>
<table class="itbl">
  <tr><td>Modelo</td><td>$(_esc "${CTX_MAC_MODEL:-N/A}")</td></tr>
  <tr><td>Serial</td><td>$(_esc "$serial")</td></tr>
  <tr><td>macOS</td><td>$(_esc "${CTX_MACOS_VER:-N/A}") ($(_esc "${CTX_ARCH:-N/A}"))</td></tr>
  <tr><td>Usuario</td><td>$(_esc "${CTX_CURRENT_USER:-N/A}")</td></tr>
  <tr><td>Hostname</td><td>$(_esc "${CTX_HOSTNAME_DISPLAY:-$PGDIAG_HOSTNAME}")</td></tr>
</table>

<h2>Red</h2>
<table class="itbl">
  <tr><td>IP origen</td><td>$(_esc "${CTX_IP:-N/A}")</td></tr>
  <tr><td>VPN</td><td>$(_esc "${CTX_VPN_STATUS:-N/A}")$([ -n "$CTX_VPN_IFACE" ] && printf ' &mdash; %s' "$(_esc "$CTX_VPN_IFACE")")</td></tr>
  <tr><td>Interfaz utilizada</td><td>$(_esc "${CTX_INTERFACE:-N/A}")</td></tr>
  <tr><td>Gateway</td><td>$(_esc "${CTX_GATEWAY:-N/A}")</td></tr>
  <tr><td>DNS</td><td>$(_esc "${CTX_DNS_SERVERS:-N/A}")</td></tr>
</table>

<h2>PostgreSQL</h2>
<table class="itbl">
  <tr><td>Cliente</td><td>$(_esc "${CTX_CLIENT:-N/A}")</td></tr>
  <tr><td>Servidor</td><td>$(_esc "${CTX_PSQL_HOST:-N/A}"):$(_esc "${CTX_PSQL_PORT:-5432}")</td></tr>
  <tr><td>Usuario / Base de datos</td><td>$(_esc "${CTX_PSQL_USER:-N/A}") / $(_esc "${CTX_PSQL_DB:-N/A}")</td></tr>
  <tr><td>Versión servidor</td><td>$(_esc "${CTX_PSQL_SERVER_VER:-N/A}")</td></tr>
  <tr><td>Puerto ${CTX_PSQL_PORT:-5432}</td><td>$(_esc "${CTX_TCP_5432:-N/A}")</td></tr>
  <tr><td>Resultado conexión</td><td><strong>$(_esc "${CTX_PSQL_RESULT:-N/A}")</strong></td></tr>
  <tr><td>Tiempo de conexión</td><td>$(_esc "${CTX_PSQL_TIME:-N/A}")</td></tr>
</table>

<h2>Seguridad</h2>
<table class="itbl">
  <tr><td>Workspace ONE</td><td>$(_esc "${CTX_WS1_STATUS:-N/A}")</td></tr>
  <tr><td>CrowdStrike</td><td>$(_esc "${CTX_CS_STATUS:-N/A}")</td></tr>
</table>

<h2>Estado de pruebas</h2>
<table class="res">
  <thead><tr><th>Módulo</th><th>Estado</th><th>Detalle</th></tr></thead>
  <tbody>
HTMLBODY

  # Filas de la tabla
  local line
  while IFS= read -r line; do
    [ -z "$line" ] && continue
    local s rc d label badge
    s="$(echo "$line" | cut -d'|' -f1)"
    rc="$(echo "$line" | cut -d'|' -f4)"
    d="$(echo "$line" | cut -d'|' -f7)"
    label="$(_rc_label "$rc")"
    case "$rc" in
      0) badge="ok" ;; 1) badge="warn" ;; 2) badge="err" ;; *) badge="skip" ;;
    esac
    printf '    <tr><td>%s</td><td><span class="badge %s">%s</span></td><td>%s</td></tr>\n' \
      "$(_esc "$s")" "$badge" "$label" "$(_esc "$d")" >> "$REPORT_HTML"
  done < <(printf "%b" "$MODULE_RESULTS")

  cat >> "$REPORT_HTML" <<HTMLFOOTER
  </tbody>
</table>

<h2>Conclusión</h2>
<div class="cls-box" style="color:${cls_color}">${cls_icon} &nbsp;${cls_text}</div>

<h2>Hipótesis (ordenadas por probabilidad)</h2>
<div class="hyp-box">
  <div class="hyp-note">Estas hipótesis se derivan exclusivamente de la evidencia recopilada. No representan una causa confirmada.</div>
  <ol>
HTMLFOOTER

  printf "%b" "$PSQL_HYPOTHESES" | while IFS= read -r h; do
    [ -z "$h" ] && continue
    local text="${h#[0-9]. }"
    printf '    <li>%s</li>\n' "$(_esc "$text")" >> "$REPORT_HTML"
  done

  cat >> "$REPORT_HTML" <<HTMLEND
  </ol>
</div>

<div class="footer">PGDiagnostic v${PGDIAG_VERSION} &mdash; ${PGDIAG_ORG} &mdash; ${PGDIAG_DATE_HUMAN}</div>
</body></html>
HTMLEND

  log "OK" "Executive_Report.html generado"
  tl "Executive_Report.html"
}

# =============================================================================
# _finalize_timeline — Cierra el timeline con duración total
# =============================================================================
_finalize_timeline() {
  local t_end elapsed
  t_end="$(date +%s)"
  elapsed=$(( t_end - PGDIAG_START_EPOCH ))

  {
    printf '%s  ZIP generado\n' "$(date '+%H:%M:%S')"
    printf '\n# Duración total: %ds\n' "$elapsed"
    printf '# === FIN ===\n'
  } >> "$TIMELINE_FILE"

  log "OK" "Timeline.txt finalizado"
}

# =============================================================================
# _create_zip — Empaqueta la carpeta en ZIP en el Desktop
# =============================================================================
_create_zip() {
  local zip_name="PGDiagnostic_${PGDIAG_HOSTNAME}_${PGDIAG_TIMESTAMP}.zip"
  local zip_path="${REAL_HOME}/Desktop/${zip_name}"
  local dir_name
  dir_name="$(basename "$OUTPUT_DIR")"

  log "INFO" "Creando ZIP..."

  if check_bin zip; then
    ( cd "${REAL_HOME}/Desktop" && \
      zip -r "$zip_name" "$dir_name" >/dev/null 2>&1 )
    local rc=$?

    if [ $rc -eq 0 ] && [ -f "$zip_path" ]; then
      local sz
      sz="$(du -sh "$zip_path" 2>/dev/null | awk '{print $1}')"
      log "OK" "ZIP: ${zip_path} (${sz})"
      record "ZIP final" "$RC_OK" "${zip_name} (${sz})"
      ZIP_FINAL_PATH="$zip_path"
    else
      log "WARN" "No se pudo crear el ZIP (rc=${rc})"
      record "ZIP final" "$RC_WARN" "Error al crear ZIP"
      ZIP_FINAL_PATH=""
    fi
  else
    # Fallback: tar.gz
    local tar_name="${zip_name%.zip}.tar.gz"
    local tar_path="${REAL_HOME}/Desktop/${tar_name}"
    ( cd "${REAL_HOME}/Desktop" && \
      tar -czf "$tar_name" "$dir_name" >/dev/null 2>&1 )

    if [ -f "$tar_path" ]; then
      local sz
      sz="$(du -sh "$tar_path" 2>/dev/null | awk '{print $1}')"
      log "OK" "tar.gz: ${tar_path} (${sz})"
      record "ZIP final" "$RC_OK" "${tar_name} (${sz}) [tar.gz]"
      ZIP_FINAL_PATH="$tar_path"
    else
      log "WARN" "No se pudo crear el archivo comprimido"
      record "ZIP final" "$RC_WARN" "Error al empaquetar"
      ZIP_FINAL_PATH=""
    fi
  fi

  tl "ZIP generado"
}

# =============================================================================
# _print_summary — Resumen final en consola
# =============================================================================
_print_summary() {
  local ok_count warn_count error_count
  ok_count="$(printf "%b" "$MODULE_RESULTS" | grep -c "|||0|||" || echo 0)"
  warn_count="$(printf "%b" "$MODULE_RESULTS" | grep -c "|||1|||" || echo 0)"
  error_count="$(printf "%b" "$MODULE_RESULTS" | grep -c "|||2|||" || echo 0)"

  local cls_label
  case "$CTX_CLASSIFICATION" in
    green)  cls_label="${C_BGREEN}🟢  Problema no reproducido${C_RST}" ;;
    yellow) cls_label="${C_YELLOW}🟡  Problema reproducido con evidencia insuficiente${C_RST}" ;;
    red)    cls_label="${C_RED}🔴  Problema reproducido con evidencia sólida${C_RST}" ;;
    *)      cls_label="⚪  Sin clasificación" ;;
  esac

  printf "\n"
  printf "  ${C_BCYAN}==================================================${C_RST}\n"
  printf "  ${C_BCYAN}  Diagnóstico completado${C_RST}\n"
  printf "  ${C_BCYAN}==================================================${C_RST}\n"
  printf "\n"
  printf "  ${C_BGREEN}✓${C_RST}  Pasaron  : %s\n" "$ok_count"
  printf "  ${C_YELLOW}!${C_RST}  Avisos   : %s\n" "$warn_count"
  printf "  ${C_RED}✗${C_RST}  Fallaron : %s\n" "$error_count"
  printf "\n"
  printf "  Resultado PostgreSQL  : ${C_BOLD}%s${C_RST}\n" "${CTX_PSQL_RESULT:-N/A}"
  printf "  Tiempo de conexión    : ${C_BOLD}%s${C_RST}\n" "${CTX_PSQL_TIME:-N/A}"
  printf "\n"
  printf "  Conclusión: %b\n" "$cls_label"
  printf "\n"
  sep
  printf "  ${C_GRAY}Carpeta  : %s${C_RST}\n" "$OUTPUT_DIR"
  printf "  ${C_GRAY}Informe  : %s${C_RST}\n" "$REPORT_HTML"
  [ -n "${ZIP_FINAL_PATH:-}" ] && \
    printf "  ${C_BGREEN}ZIP listo: %s${C_RST}\n" "$ZIP_FINAL_PATH"
  sep
  printf "\n"
}
