#!/bin/bash
# =============================================================================
# PGDiagnostic — lib/diag_postgresql.sh
# Responsabilidad: flujo de diagnóstico PostgreSQL (psql y DBeaver),
#   tcpdump, análisis de resultado e hipótesis
# =============================================================================

# Rutas conocidas de psql
readonly _PSQL_PATHS=(
  "/usr/local/bin/psql"
  "/opt/homebrew/bin/psql"
  "/Library/PostgreSQL/16/bin/psql"
  "/Library/PostgreSQL/15/bin/psql"
  "/Library/PostgreSQL/14/bin/psql"
  "/Library/PostgreSQL/13/bin/psql"
  "/usr/bin/psql"
)

# =============================================================================
# diag_postgresql — Menú cliente y despacho de flujo
# =============================================================================
diag_postgresql() {
  printf "\n"
  sep
  printf "  ${C_WHITE}¿Qué cliente utiliza?${C_RST}\n"
  sep
  printf "\n"
  printf "  1) psql\n"
  printf "  2) DBeaver\n"
  printf "\n"
  printf "  Opción: "
  local choice
  read -r choice

  case "$choice" in
    1) CTX_CLIENT="psql";    _pg_flow_psql ;;
    2) CTX_CLIENT="dbeaver"; _pg_flow_dbeaver ;;
    *)
      printf "\n  ${C_RED}Opción inválida.${C_RST}\n"
      diag_postgresql
      ;;
  esac
}

# =============================================================================
# _ask_pg_params — Solicita parámetros de conexión de forma interactiva
# =============================================================================
_ask_pg_params() {
  printf "\n"
  sep
  printf "  ${C_WHITE}Parámetros de conexión PostgreSQL${C_RST}\n"
  sep
  printf "\n"

  printf "  Host / IP del servidor PostgreSQL : "
  read -r CTX_PSQL_HOST
  CTX_PSQL_HOST="${CTX_PSQL_HOST:-localhost}"

  printf "  Puerto [5432]                      : "
  read -r _port
  CTX_PSQL_PORT="${_port:-5432}"
  unset _port

  printf "  Base de datos [postgres]           : "
  read -r CTX_PSQL_DB
  CTX_PSQL_DB="${CTX_PSQL_DB:-postgres}"

  printf "  Usuario                            : "
  read -r CTX_PSQL_USER
  CTX_PSQL_USER="${CTX_PSQL_USER:-postgres}"

  printf "\n"
  log "INFO" "PG params: ${CTX_PSQL_USER}@${CTX_PSQL_HOST}:${CTX_PSQL_PORT}/${CTX_PSQL_DB}"
}

# =============================================================================
# _find_psql — Localiza el binario psql. Retorna ruta o vacío.
# =============================================================================
_find_psql() {
  local p
  for p in "${_PSQL_PATHS[@]}"; do
    [ -x "$p" ] && { echo "$p"; return 0; }
  done
  check_bin psql && { echo "psql"; return 0; }
  echo ""
  return 1
}

# =============================================================================
# _get_psql_server_version <psql_bin> — Intenta obtener versión del servidor
# =============================================================================
_get_psql_server_version() {
  local psql_bin="$1"
  # Sólo intenta si el puerto ya respondió OK
  if [ "$CTX_TCP_5432" = "Abierto" ] && [ -n "$CTX_PSQL_USER" ]; then
    PGCONNECT_TIMEOUT=5 "$psql_bin" \
      -h "$CTX_PSQL_HOST" -p "$CTX_PSQL_PORT" \
      -U "$CTX_PSQL_USER" -d "$CTX_PSQL_DB" \
      -t -c "SELECT version();" 2>/dev/null | head -1 | xargs
  fi
}

# =============================================================================
# _start_tcpdump <iface> <pcap_file> <host> <port>
# Inicia tcpdump en background con filtro BPF preciso.
# Retorna PID o vacío en fallo.
# =============================================================================
_start_tcpdump() {
  local iface="$1"
  local pcap_file="$2"
  local host="$3"
  local port="$4"

  if ! check_bin tcpdump; then
    log "WARN" "tcpdump no disponible"
    record "tcpdump" "$RC_WARN" "No disponible en este sistema"
    echo ""
    return 1
  fi

  # Filtro: sólo tráfico al host y puerto PostgreSQL
  local filter="host ${host} and tcp port ${port}"

  tcpdump \
    -i "$iface" \
    -w "$pcap_file" \
    -s 0 \
    "$filter" \
    2>/dev/null &

  local pid=$!
  sleep 0.5

  if kill -0 "$pid" 2>/dev/null; then
    CTX_TCPDUMP_PID="$pid"
    CTX_PCAP_FILE="$pcap_file"
    log "OK" "tcpdump PID=${pid} interfaz=${iface} filtro='${filter}'"
    record "tcpdump" "$RC_OK" "Capturando en ${iface}"
    tl "Inicio tcpdump (${iface})"
    echo "$pid"
    return 0
  else
    log "WARN" "tcpdump no arrancó correctamente"
    record "tcpdump" "$RC_WARN" "No arrancó"
    echo ""
    return 1
  fi
}

# =============================================================================
# _stop_tcpdump <pid> — Detiene tcpdump limpiamente
# =============================================================================
_stop_tcpdump() {
  local pid="$1"
  [ -z "$pid" ] && return

  if kill -0 "$pid" 2>/dev/null; then
    kill "$pid" 2>/dev/null
    wait "$pid" 2>/dev/null
    log "OK" "tcpdump detenido (PID=${pid})"
    tl "Fin tcpdump"
  fi
}

# =============================================================================
# _generate_pcap_summary — Genera resumen legible del pcap
# =============================================================================
_generate_pcap_summary() {
  local pcap_file="$1"
  local summary="${EVIDENCE_DIR}/red/tcpdump_summary.txt"

  [ ! -f "$pcap_file" ] || [ ! -s "$pcap_file" ] && return

  {
    printf '# ======================================================\n'
    printf '# RESUMEN CAPTURA TCPDUMP\n'
    printf '# Archivo: %s\n' "$(basename "$pcap_file")"
    printf '# Tamaño: %s\n' "$(du -sh "$pcap_file" 2>/dev/null | awk '{print $1}')"
    printf '# ======================================================\n\n'

    printf '# Todos los paquetes:\n# ---\n'
    tcpdump -r "$pcap_file" -nn -q 2>/dev/null | head -200

    printf '\n# Flags SYN / RST / FIN (indicadores clave de problemas):\n# ---\n'
    tcpdump -r "$pcap_file" -nn \
      'tcp[tcpflags] & (tcp-syn|tcp-rst|tcp-fin) != 0' \
      2>/dev/null | head -100

    printf '\n# Conteo de paquetes por dirección:\n# ---\n'
    tcpdump -r "$pcap_file" -nn -q 2>/dev/null | \
      awk '{print $3}' | sort | uniq -c | sort -rn | head -20

  } > "$summary" 2>/dev/null

  log "OK" "Resumen tcpdump generado"
}

# =============================================================================
# _run_psql_test — Ejecuta la prueba de conexión psql
# Captura stdout, stderr, rc y tiempo. NO almacena password.
# Popula CTX_PSQL_RESULT, CTX_PSQL_TIME, CTX_PSQL_RC
# =============================================================================
_run_psql_test() {
  local psql_bin="$1"
  local outfile="${EVIDENCE_DIR}/postgresql/psql_test.txt"
  local stdout_tmp stderr_tmp
  stdout_tmp="$(mktemp)"
  stderr_tmp="$(mktemp)"

  log "STEP" "Ejecutando conexión PostgreSQL"
  tl "Inicio PostgreSQL"

  # Password solicitada de forma segura via stdin de la terminal,
  # nunca guardada en archivo ni variable exportada
  printf "\n  ${C_YELLOW}Password de ${CTX_PSQL_USER}${C_RST} (no se almacenará): "
  local pg_pass
  read -r -s pg_pass
  printf "\n\n"

  local t_start t_end
  t_start="$(date +%s)"

  PGCONNECT_TIMEOUT=10 PGPASSWORD="$pg_pass" "$psql_bin" \
    -h "$CTX_PSQL_HOST" \
    -p "$CTX_PSQL_PORT" \
    -U "$CTX_PSQL_USER" \
    -d "$CTX_PSQL_DB" \
    -c "SELECT version();" \
    -c "SELECT now() AS server_time;" \
    -c "SELECT count(*) AS active_connections FROM pg_stat_activity WHERE state='active';" \
    1>"$stdout_tmp" \
    2>"$stderr_tmp"

  CTX_PSQL_RC=$?
  t_end="$(date +%s)"
  CTX_PSQL_TIME="$(( t_end - t_start ))s"

  # Limpiar password de memoria lo antes posible
  pg_pass=""
  unset pg_pass

  CTX_PSQL_STDOUT="$(cat "$stdout_tmp")"
  CTX_PSQL_STDERR="$(cat "$stderr_tmp")"
  rm -f "$stdout_tmp" "$stderr_tmp"

  {
    printf '# ======================================================\n'
    printf '# PRUEBA DE CONEXIÓN POSTGRESQL\n'
    printf '# Host: %s:%s  User: %s  DB: %s\n' \
      "$CTX_PSQL_HOST" "$CTX_PSQL_PORT" "$CTX_PSQL_USER" "$CTX_PSQL_DB"
    printf '# RC: %s  Tiempo: %s\n' "$CTX_PSQL_RC" "$CTX_PSQL_TIME"
    printf '# ======================================================\n\n'
    printf '## STDOUT:\n%s\n\n' "$CTX_PSQL_STDOUT"
    printf '## STDERR:\n%s\n\n' "$CTX_PSQL_STDERR"
  } > "$outfile"

  # Clasificar resultado
  if [ "$CTX_PSQL_RC" -eq 0 ]; then
    CTX_PSQL_RESULT="EXITOSO"
    log "OK" "Conexión PostgreSQL exitosa (${CTX_PSQL_TIME})"
    tl "PostgreSQL EXITOSO (${CTX_PSQL_TIME})"
    record "PostgreSQL - Conexión" "$RC_OK" "Exitosa en ${CTX_PSQL_TIME}"
  else
    _classify_psql_error
  fi
}

# =============================================================================
# _classify_psql_error — Clasifica el error de psql y popula CTX_PSQL_RESULT
# =============================================================================
_classify_psql_error() {
  local stderr="$CTX_PSQL_STDERR"

  if echo "$stderr" | grep -qiE "timeout|timed out"; then
    CTX_PSQL_RESULT="TIMEOUT (${CTX_PSQL_TIME})"
    log "ERROR" "PostgreSQL: Timeout (${CTX_PSQL_TIME})"
    tl "Timeout PostgreSQL (${CTX_PSQL_TIME})"
    record "PostgreSQL - Conexión" "$RC_ERROR" "Timeout en ${CTX_PSQL_TIME}"

  elif echo "$stderr" | grep -qiE "Connection refused"; then
    CTX_PSQL_RESULT="CONEXIÓN RECHAZADA"
    log "ERROR" "PostgreSQL: Connection refused"
    tl "PostgreSQL Connection refused"
    record "PostgreSQL - Conexión" "$RC_ERROR" "Connection refused"

  elif echo "$stderr" | grep -qiE "password|authentication failed|no password"; then
    CTX_PSQL_RESULT="ERROR DE AUTENTICACIÓN"
    log "ERROR" "PostgreSQL: Authentication failed"
    tl "PostgreSQL Auth failed"
    record "PostgreSQL - Conexión" "$RC_ERROR" "Authentication failed"

  elif echo "$stderr" | grep -qiE "does not exist|no existe"; then
    CTX_PSQL_RESULT="BASE DE DATOS NO EXISTE"
    log "ERROR" "PostgreSQL: Database does not exist"
    tl "PostgreSQL DB not found"
    record "PostgreSQL - Conexión" "$RC_ERROR" "Database '${CTX_PSQL_DB}' does not exist"

  elif echo "$stderr" | grep -qiE "SSL|certificate"; then
    CTX_PSQL_RESULT="ERROR SSL/TLS"
    log "ERROR" "PostgreSQL: SSL error"
    tl "PostgreSQL SSL error"
    record "PostgreSQL - Conexión" "$RC_ERROR" "SSL/TLS error"

  elif echo "$stderr" | grep -qiE "Name or service not known|could not resolve"; then
    CTX_PSQL_RESULT="ERROR DNS — HOST NO RESUELTO"
    log "ERROR" "PostgreSQL: DNS resolution failed"
    tl "PostgreSQL DNS failed"
    record "PostgreSQL - Conexión" "$RC_ERROR" "DNS: host no resuelto"

  else
    CTX_PSQL_RESULT="ERROR (rc=${CTX_PSQL_RC})"
    log "ERROR" "PostgreSQL: rc=${CTX_PSQL_RC}"
    tl "PostgreSQL error rc=${CTX_PSQL_RC}"
    record "PostgreSQL - Conexión" "$RC_ERROR" "Error rc=${CTX_PSQL_RC} — ver psql_test.txt"
  fi
}

# =============================================================================
# _collect_pg_local_info — Info local de PostgreSQL (puertos, procesos, binario)
# =============================================================================
_collect_pg_local_info() {
  local outfile="${EVIDENCE_DIR}/postgresql/pg_local.txt"

  {
    printf '# ======================================================\n'
    printf '# POSTGRESQL LOCAL\n'
    printf '# ======================================================\n\n'

    printf '# Versión de psql\n# ---\n'
    "${CTX_PSQL_BIN:-psql}" --version 2>&1 || echo "N/A"
    printf '\n'

    printf '# Procesos postgres\n# ---\n'
    ps aux 2>/dev/null | grep -E "[p]ostgres|[P]ostgreSQL" || echo "No detectado"
    printf '\n'

    printf '# Puerto %s en escucha\n# ---\n' "$CTX_PSQL_PORT"
    lsof -iTCP:"$CTX_PSQL_PORT" -sTCP:LISTEN -n -P 2>/dev/null || \
      netstat -an 2>/dev/null | grep "LISTEN" | grep ":${CTX_PSQL_PORT}" || \
      echo "No escuchando localmente"
    printf '\n'

  } > "$outfile" 2>&1
}

# =============================================================================
# _pg_flow_psql — Flujo completo automatizado con psql
# Los módulos de sistema, red y seguridad SIEMPRE se ejecutan primero.
# Si psql no está instalado se marca como SKIPPED y el reporte se genera igual.
# =============================================================================
_pg_flow_psql() {
  log "STEP" "Diagnóstico PostgreSQL — psql"

  # 1. Verificar psql disponible (NO abortar si falta — SKIPPED)
  CTX_PSQL_BIN="$(_find_psql)"
  if [ -z "$CTX_PSQL_BIN" ]; then
    log "WARN" "psql no encontrado — la prueba de conexión quedará como SKIPPED"
    record "PostgreSQL - psql bin" "$RC_SKIP" "psql no instalado en este equipo"
  else
    log "OK" "psql: ${CTX_PSQL_BIN}"
    record "PostgreSQL - psql bin" "$RC_OK" "$CTX_PSQL_BIN"
  fi

  # 2. Solicitar parámetros de conexión (host/puerto necesarios para tcpdump y TCP test)
  _ask_pg_params

  # 3. Recopilación del sistema  ← SIEMPRE primero
  collect_system

  # 4. Recopilación de red       ← SIEMPRE segundo
  collect_network

  # 5. Workspace ONE y CrowdStrike ← SIEMPRE tercero
  collect_workspace_one
  collect_crowdstrike

  # 6. Detectar interfaz específica hacia el host PG
  detect_route_to_host "$CTX_PSQL_HOST"

  # 7. Verificar puerto TCP
  check_tcp_port "$CTX_PSQL_HOST" "$CTX_PSQL_PORT"

  # 8. Info local PostgreSQL (binario, procesos, puerto local)
  _collect_pg_local_info

  # 9. Si psql no está disponible → marcar y saltar prueba
  if [ -z "$CTX_PSQL_BIN" ]; then
    log "WARN" "Prueba de conexión PostgreSQL omitida (psql no instalado)"
    CTX_PSQL_RESULT="SKIPPED — psql no instalado"
    CTX_PSQL_TIME="N/A"
    CTX_PSQL_RC="N/A"
    record "PostgreSQL - Conexión" "$RC_SKIP" "psql no instalado — instalar con: brew install libpq"
    tl "PostgreSQL SKIPPED (psql no instalado)"
    _analyze_result
    generate_report
    return $RC_SKIP
  fi

  # 10. Iniciar tcpdump SOLO sobre la interfaz detectada
  local pcap_file="${EVIDENCE_DIR}/postgresql/tcpdump_${PGDIAG_TIMESTAMP}.pcap"
  local tcpdump_pid
  tcpdump_pid="$(_start_tcpdump "$CTX_INTERFACE" "$pcap_file" \
                                "$CTX_PSQL_HOST" "$CTX_PSQL_PORT")"
  sleep 1  # dar tiempo al tcpdump para inicializarse

  # 11. Ejecutar prueba psql
  _run_psql_test "$CTX_PSQL_BIN"

  # 12. Detener tcpdump inmediatamente
  _stop_tcpdump "$tcpdump_pid"

  # Generar resumen pcap
  [ -f "$pcap_file" ] && _generate_pcap_summary "$pcap_file"

  # Intentar obtener versión del servidor (si la conexión fue exitosa)
  if [ "$CTX_PSQL_RESULT" = "EXITOSO" ]; then
    CTX_PSQL_SERVER_VER="$(echo "$CTX_PSQL_STDOUT" | \
      grep -o 'PostgreSQL [0-9.]*' | head -1 || echo 'N/A')"
  fi

  # 13. Analizar y generar hipótesis
  _analyze_result

  # 14. Generar reporte y ZIP
  generate_report
}

# =============================================================================
# _pg_flow_dbeaver — Flujo con DBeaver (captura manual interactiva)
# =============================================================================
_pg_flow_dbeaver() {
  log "STEP" "Diagnóstico PostgreSQL — DBeaver"

  # 1. Parámetros de conexión (para filtrar tcpdump)
  _ask_pg_params

  # 2. Recopilación del sistema
  collect_system
  tl "Sistema"

  # 3. Red
  collect_network

  # 4. Workspace ONE y CrowdStrike
  collect_workspace_one
  collect_crowdstrike

  # 5. Interfaz hacia PG
  detect_route_to_host "$CTX_PSQL_HOST"

  # 6. Puerto TCP
  check_tcp_port "$CTX_PSQL_HOST" "$CTX_PSQL_PORT"

  # 7. Info local PG
  _collect_pg_local_info

  # 8. Instrucciones al usuario
  printf "\n"
  sep
  printf "  ${C_WHITE}Captura de tráfico — DBeaver${C_RST}\n"
  sep
  printf "\n"
  printf "  Se iniciará la captura de tráfico.\n"
  printf "  Abra DBeaver.\n"
  printf "  Reproduzca el problema.\n"
  printf "  Cuando termine vuelva aquí y presione ${C_BOLD}ENTER${C_RST}.\n"
  printf "\n"
  printf "  Presione ENTER para iniciar la captura..."
  read -r _

  # 9. Iniciar tcpdump
  local pcap_file="${EVIDENCE_DIR}/postgresql/tcpdump_dbeaver_${PGDIAG_TIMESTAMP}.pcap"
  local tcpdump_pid
  tcpdump_pid="$(_start_tcpdump "$CTX_INTERFACE" "$pcap_file" \
                                "$CTX_PSQL_HOST" "$CTX_PSQL_PORT")"

  if [ -n "$tcpdump_pid" ]; then
    printf "\n  ${C_BGREEN}✓${C_RST}  Captura iniciada en ${CTX_INTERFACE}\n"
  else
    printf "\n  ${C_YELLOW}!${C_RST}  tcpdump no disponible — continúe sin captura\n"
  fi

  printf "\n  ${C_CYAN}Reproduzca el problema en DBeaver.${C_RST}\n"
  printf "  Cuando finalice, presione ENTER..."
  read -r _

  # 10. Detener tcpdump
  _stop_tcpdump "$tcpdump_pid"
  [ -f "$pcap_file" ] && _generate_pcap_summary "$pcap_file"

  # Sin ejecución automática de psql
  CTX_PSQL_RESULT="Diagnóstico manual con DBeaver"
  CTX_PSQL_TIME="N/A"
  CTX_PSQL_RC="N/A"
  record "PostgreSQL - Conexión" "$RC_SKIP" "Flujo DBeaver — revisar pcap"

  _analyze_result
  generate_report
}

# =============================================================================
# _analyze_result — Clasifica el resultado y genera hipótesis desde evidencia
# Popula CTX_CLASSIFICATION y PSQL_HYPOTHESES
# NUNCA afirma una causa. Solo infiere hipótesis sustentadas en evidencia.
# =============================================================================
_analyze_result() {
  log "STEP" "Análisis de evidencia"
  tl "Análisis"

  # --- Clasificación del resultado ---
  if [ "$CTX_PSQL_RESULT" = "EXITOSO" ]; then
    CTX_CLASSIFICATION="green"
  elif [ "$CTX_CLIENT" = "dbeaver" ]; then
    CTX_CLASSIFICATION="yellow"
  elif echo "$CTX_PSQL_RESULT" | grep -qiE "TIMEOUT|RECHAZADA|SSL"; then
    CTX_CLASSIFICATION="red"
  else
    CTX_CLASSIFICATION="yellow"
  fi

  # --- Generar hipótesis basadas en combinación de evidencia ---
  # Señales clave disponibles:
  #   CTX_TCP_5432       : Abierto | Cerrado
  #   CTX_VPN_STATUS     : Activa | No detectada
  #   CTX_PSQL_RESULT    : tipo de error
  #   CTX_CS_STATUS      : estado CrowdStrike
  #   CTX_WS1_STATUS     : estado Workspace ONE
  #   CTX_PSQL_TIME      : tiempo hasta fallo
  #   CTX_CLIENT         : psql | dbeaver

  PSQL_HYPOTHESES=""

  case "$CTX_PSQL_RESULT" in

    "TIMEOUT"*)
      # TCP abierto + timeout del protocolo PG = evidencia de intermediario L7
      if [ "$CTX_TCP_5432" = "Abierto" ]; then
        PSQL_HYPOTHESES="1. Dispositivo intermedio (Firewall L7, IPS, DAM Imperva, DLP o proxy) acepta el handshake TCP pero bloquea o no reenvía el Startup Packet del protocolo PostgreSQL — patrón consistente con inspección deep packet en el payload de la aplicación.\n"
        PSQL_HYPOTHESES="${PSQL_HYPOTHESES}2. Política de seguridad en AWS Security Group o Network ACL que permite TCP:${CTX_PSQL_PORT} pero bloquea el tráfico de aplicación por origen o protocolo.\n"
        if [ "$CTX_VPN_STATUS" = "Activa" ]; then
          PSQL_HYPOTHESES="${PSQL_HYPOTHESES}3. VPN activa (${CTX_VPN_IFACE}) enrutando el tráfico por un path diferente con restricciones adicionales sobre el protocolo PostgreSQL.\n"
        else
          PSQL_HYPOTHESES="${PSQL_HYPOTHESES}3. La red WiFi corporativa aplica políticas de inspección que no están presentes en el acceso por VPN — diferencia de path explica el comportamiento intermitente.\n"
        fi
        PSQL_HYPOTHESES="${PSQL_HYPOTHESES}4. CrowdStrike Falcon (${CTX_CS_STATUS}) aplicando política de red que filtra el protocolo PostgreSQL en esta red — verificar exclusiones en la consola Falcon.\n"
        PSQL_HYPOTHESES="${PSQL_HYPOTHESES}5. RDS PostgreSQL descartando la conexión silenciosamente por política de pg_hba.conf o SSL requerido desde esta IP de origen.\n"
      else
        PSQL_HYPOTHESES="1. Puerto TCP:${CTX_PSQL_PORT} no alcanzable — firewall de red o AWS Security Group bloqueando el acceso desde esta subred.\n"
        PSQL_HYPOTHESES="${PSQL_HYPOTHESES}2. Servicio PostgreSQL en ${CTX_PSQL_HOST} no está corriendo o escuchando en un puerto diferente.\n"
        PSQL_HYPOTHESES="${PSQL_HYPOTHESES}3. Enrutamiento incorrecto — el tráfico no llega al servidor por ruta incorrecta o gateway inadecuado.\n"
        PSQL_HYPOTHESES="${PSQL_HYPOTHESES}4. Workspace ONE aplicando restricción de red que bloquea el tráfico saliente al puerto.\n"
        PSQL_HYPOTHESES="${PSQL_HYPOTHESES}5. DNS resolviendo el host a una IP incorrecta — verificar nslookup desde la misma red.\n"
      fi
      ;;

    "CONEXIÓN RECHAZADA")
      PSQL_HYPOTHESES="1. PostgreSQL no está corriendo en ${CTX_PSQL_HOST}:${CTX_PSQL_PORT} o escucha en un puerto diferente al configurado.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}2. Firewall del servidor enviando RST activamente en lugar de descartar el paquete.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}3. listen_addresses en postgresql.conf no incluye la IP de red (solo localhost) — común en instalaciones por defecto.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}4. Puerto incorrecto — el servidor escucha en un puerto diferente al ${CTX_PSQL_PORT}.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}5. AWS Security Group con regla de deny explícita para este origen.\n"
      ;;

    "ERROR DE AUTENTICACIÓN")
      PSQL_HYPOTHESES="1. Credenciales incorrectas para el usuario '${CTX_PSQL_USER}' en este servidor PostgreSQL.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}2. Método de autenticación en pg_hba.conf no compatible con el cliente (ej. scram-sha-256 vs md5).\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}3. Usuario '${CTX_PSQL_USER}' no tiene permisos de acceso a la base de datos '${CTX_PSQL_DB}'.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}4. pg_hba.conf no permite conexiones desde la IP de origen actual (diferente al acceder por VPN).\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}5. Certificado SSL requerido y no proporcionado — verify-ca o verify-full configurado en el servidor.\n"
      ;;

    "ERROR SSL/TLS")
      PSQL_HYPOTHESES="1. Dispositivo intermedio (proxy, IPS o DLP) realizando SSL inspection y presentando un certificado diferente al del servidor RDS — el cliente rechaza el certificado.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}2. Versión TLS del cliente incompatible con la versión mínima requerida por el servidor PostgreSQL.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}3. Certificado CA del RDS no está en el bundle de confianza del sistema macOS.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}4. Parámetro sslmode incorrecto en la cadena de conexión.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}5. CrowdStrike realizando inspección SSL del tráfico saliente hacia el exterior.\n"
      ;;

    "ERROR DNS"*)
      PSQL_HYPOTHESES="1. El nombre de host '${CTX_PSQL_HOST}' no resuelve desde esta red — diferente servidor DNS o zona DNS privada no accesible sin VPN.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}2. DNS Split-Horizon: el nombre resuelve por VPN pero no desde la red corporativa WiFi.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}3. Servidores DNS corporativos bloqueando la resolución de dominios externos (ej. *.rds.amazonaws.com).\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}4. Configuración DNS incorrecta empujada por Workspace ONE MDM en esta red.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}5. El host es una IP y hay un error de tipeo o entorno incorrecto.\n"
      ;;

    "EXITOSO")
      CTX_CLASSIFICATION="green"
      PSQL_HYPOTHESES="1. Conexión exitosa — no se reprodujo el problema en este diagnóstico.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}2. Si el problema es intermitente, repetir el diagnóstico en el momento exacto del fallo.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}3. Verificar si el problema ocurre solo con ciertos usuarios, bases de datos o desde ciertos dispositivos.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}4. Revisar el tcpdump capturado para detectar retransmisiones TCP que indiquen latencia o pérdida de paquetes.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}5. Comparar el pcap de esta sesión con uno capturado durante el fallo para identificar diferencias.\n"
      ;;

    *)
      # DBeaver u otros
      PSQL_HYPOTHESES="1. Revisar el archivo tcpdump.pcap con Wireshark para identificar el punto exacto donde falla la sesión.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}2. Verificar si el TCP handshake completa exitosamente o si hay un RST/FIN inesperado.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}3. Analizar si el Startup Packet de PostgreSQL es enviado y si recibe respuesta del servidor.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}4. Comparar el comportamiento desde la red WiFi corporativa vs VPN usando el mismo pcap.\n"
      PSQL_HYPOTHESES="${PSQL_HYPOTHESES}5. Dispositivo intermedio interceptando la sesión — verificar logs de Imperva DAM o Firewall L7.\n"
      ;;
  esac

  log "OK" "Análisis completado. Clasificación: ${CTX_CLASSIFICATION}"
  tl "Análisis completado (${CTX_CLASSIFICATION})"
}
