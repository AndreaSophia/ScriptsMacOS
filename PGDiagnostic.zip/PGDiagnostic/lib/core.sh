#!/bin/bash
# =============================================================================
# PGDiagnostic — lib/core.sh
# Responsabilidad: constantes, logging, timeline, dirs, banner, utilidades base
# =============================================================================

readonly PGDIAG_VERSION="1.0.0"
readonly PGDIAG_ORG="Apple Platform Team"

# En bash 3.2 la asignación de readonly debe hacerse en una sola línea
# para evitar que el subshell de $() no propague el valor correctamente
PGDIAG_HOSTNAME="$(hostname -s 2>/dev/null || echo 'unknown')"
readonly PGDIAG_HOSTNAME

PGDIAG_TIMESTAMP="$(date '+%Y%m%d_%H%M%S')"
readonly PGDIAG_TIMESTAMP

PGDIAG_DATE_HUMAN="$(date '+%d/%m/%Y %H:%M:%S')"
readonly PGDIAG_DATE_HUMAN

# IMPORTANTE: date +%s debe ejecutarse en el shell actual, no en subshell
# de una asignación readonly separada, para evitar el bug de epoch incorrecto.
# Se asigna primero y luego se declara readonly.
PGDIAG_START_EPOCH="$(date +%s)"
readonly PGDIAG_START_EPOCH

# ----------------------------------------------------------------------------
# Directorio raíz de salida — Desktop del usuario real (no root)
# ----------------------------------------------------------------------------
if [ -n "${SUDO_USER:-}" ]; then
  _REAL_HOME="$(eval echo "~${SUDO_USER}" 2>/dev/null)"
else
  _REAL_HOME="$HOME"
fi
readonly REAL_HOME="$_REAL_HOME"
unset _REAL_HOME

readonly OUTPUT_DIR="${REAL_HOME}/Desktop/PGDiagnostic_${PGDIAG_HOSTNAME}_${PGDIAG_TIMESTAMP}"
readonly EVIDENCE_DIR="${OUTPUT_DIR}/evidencias"
readonly LOG_FILE="${OUTPUT_DIR}/diagnostic.log"
readonly TIMELINE_FILE="${OUTPUT_DIR}/Timeline.txt"
readonly REPORT_TXT="${OUTPUT_DIR}/Executive_Report.txt"
readonly REPORT_HTML="${OUTPUT_DIR}/Executive_Report.html"

# ----------------------------------------------------------------------------
# Códigos de retorno estándar de módulos
# ----------------------------------------------------------------------------
readonly RC_OK=0
readonly RC_WARN=1
readonly RC_ERROR=2
readonly RC_SKIP=3

# ----------------------------------------------------------------------------
# Variables de contexto — llenadas por los módulos
# ----------------------------------------------------------------------------
CTX_MACOS_VER=""
CTX_ARCH=""
CTX_MAC_MODEL=""
CTX_CURRENT_USER=""
CTX_HOSTNAME_DISPLAY=""   # nombre amigable del equipo (ComputerName)
CTX_IP=""
CTX_VPN_STATUS=""
CTX_VPN_IFACE=""
CTX_INTERFACE=""
CTX_GATEWAY=""
CTX_DNS_SERVERS=""
CTX_TCP_5432=""
CTX_PSQL_BIN=""
CTX_PSQL_SERVER_VER=""
CTX_PSQL_HOST=""
CTX_PSQL_PORT="5432"
CTX_PSQL_USER=""
CTX_PSQL_DB=""
CTX_PSQL_RC=""
CTX_PSQL_RESULT=""
CTX_PSQL_TIME=""
CTX_PSQL_STDOUT=""
CTX_PSQL_STDERR=""
CTX_WS1_STATUS=""
CTX_CS_STATUS=""
CTX_PCAP_FILE=""
CTX_TCPDUMP_PID=""
CTX_CLIENT=""           # psql | dbeaver
CTX_CLASSIFICATION=""   # green | yellow | red

# Acumulador de resultados para el reporte
MODULE_RESULTS=""

# ----------------------------------------------------------------------------
# Colores — sólo si stdout es una terminal
# ----------------------------------------------------------------------------
if [ -t 1 ]; then
  C_RST='\033[0m'; C_BOLD='\033[1m'
  C_CYAN='\033[0;36m';  C_BCYAN='\033[1;36m'
  C_GREEN='\033[0;32m'; C_BGREEN='\033[1;32m'
  C_YELLOW='\033[0;33m'; C_RED='\033[0;31m'
  C_GRAY='\033[0;90m';  C_WHITE='\033[1;37m'
else
  C_RST=''; C_BOLD=''; C_CYAN=''; C_BCYAN=''
  C_GREEN=''; C_BGREEN=''; C_YELLOW=''; C_RED=''
  C_GRAY=''; C_WHITE=''
fi

# =============================================================================
# init_dirs — Crea la estructura de directorios de salida
# =============================================================================
init_dirs() {
  mkdir -p \
    "${EVIDENCE_DIR}/sistema" \
    "${EVIDENCE_DIR}/red" \
    "${EVIDENCE_DIR}/postgresql" \
    "${EVIDENCE_DIR}/workspace_one" \
    "${EVIDENCE_DIR}/crowdstrike" \
    2>/dev/null || {
      echo "[FATAL] No se pudo crear el directorio de salida: ${OUTPUT_DIR}" >&2
      exit 1
    }

  # Cabecera del log
  {
    echo "# PGDiagnostic v${PGDIAG_VERSION} — ${PGDIAG_ORG}"
    echo "# Inicio: ${PGDIAG_DATE_HUMAN}"
    echo "# Hostname: ${PGDIAG_HOSTNAME}"
    echo ""
  } > "${LOG_FILE}"

  # Cabecera del timeline
  {
    echo "# PGDiagnostic — Timeline"
    echo "# Inicio: ${PGDIAG_DATE_HUMAN} | Hostname: ${PGDIAG_HOSTNAME}"
    echo "#"
    echo ""
  } > "${TIMELINE_FILE}"
}

# =============================================================================
# log <NIVEL> <mensaje>
# Niveles: STEP INFO OK WARN ERROR DEBUG
# =============================================================================
log() {
  local level="$1"
  local msg="$2"
  local ts
  ts="$(date '+%H:%M:%S')"

  # Siempre al archivo de log
  printf '%s [%-5s] %s\n' "$ts" "$level" "$msg" >> "${LOG_FILE}" 2>/dev/null

  # Consola con color según nivel
  case "$level" in
    STEP)  printf "\n${C_BCYAN}  ▶  %s${C_RST}\n"  "$msg" ;;
    INFO)  printf   "  ${C_CYAN}·${C_RST}  %s\n"   "$msg" ;;
    OK)    printf   "  ${C_BGREEN}✓${C_RST}  %s\n" "$msg" ;;
    WARN)  printf   "  ${C_YELLOW}!${C_RST}  %s\n" "$msg" ;;
    ERROR) printf   "  ${C_RED}✗${C_RST}  %s\n"    "$msg" >&2 ;;
    DEBUG)
      [ "${PGDIAG_DEBUG:-0}" = "1" ] && \
        printf "  ${C_GRAY}D  %s${C_RST}\n" "$msg"
      ;;
  esac
}

# =============================================================================
# tl <evento> — Agrega entrada al timeline
# =============================================================================
tl() {
  local ts
  ts="$(date '+%H:%M:%S')"
  printf '%s  %s\n' "$ts" "$1" >> "${TIMELINE_FILE}" 2>/dev/null
  log "DEBUG" "TL: $1"
}

# =============================================================================
# record <sección> <RC_*> <detalle>
# Acumula resultado de módulo para el reporte
# =============================================================================
record() {
  local section="$1"
  local status="$2"
  local detail="$3"
  MODULE_RESULTS="${MODULE_RESULTS}${section}|||${status}|||${detail}\n"
}

# =============================================================================
# run_collect <descripción> <archivo_destino> <cmd...>
# Ejecuta un comando y guarda stdout+stderr en el archivo de evidencia
# Retorna el rc original del comando
# =============================================================================
run_collect() {
  local desc="$1"
  local outfile="$2"
  shift 2

  log "INFO" "$desc"
  {
    printf '# %s\n# Cmd: %s\n# Time: %s\n# ---\n' \
      "$desc" "$*" "$(date '+%Y-%m-%d %H:%M:%S')"
    "$@" 2>&1
    printf '\n'
  } >> "$outfile"

  local rc=$?
  [ $rc -ne 0 ] && log "WARN" "$desc → rc=$rc"
  return $rc
}

# =============================================================================
# run_collect_timeout <segundos> <descripción> <archivo_destino> <cmd...>
# NOTA: No usar subshell con return — el rc se pierde en bash 3.2.
#       Se captura en variable temporal para preservarlo.
# =============================================================================
run_collect_timeout() {
  local secs="$1"
  local desc="$2"
  local outfile="$3"
  shift 3

  log "INFO" "$desc (timeout ${secs}s)"

  # Cabecera fuera del subshell para que el rc sea capturado correctamente
  printf '# %s\n# Cmd: %s\n# Timeout: %ss\n# Time: %s\n# ---\n' \
    "$desc" "$*" "$secs" "$(date '+%Y-%m-%d %H:%M:%S')" >> "$outfile"

  timeout "$secs" "$@" >> "$outfile" 2>&1
  local rc=$?

  printf '# exit: %d\n\n' "$rc" >> "$outfile"

  if [ $rc -eq 124 ]; then
    log "WARN" "$desc → timeout (${secs}s)"
  elif [ $rc -ne 0 ]; then
    log "WARN" "$desc → rc=$rc"
  fi

  return $rc
}

# =============================================================================
# check_bin <binario> — Retorna 0 si existe en PATH o ruta directa
# =============================================================================
check_bin() {
  command -v "$1" >/dev/null 2>&1
}

# =============================================================================
# require_root — Aborta si no se ejecuta como root
# =============================================================================
require_root() {
  if [ "${EUID:-$(id -u)}" -ne 0 ]; then
    printf "\n${C_RED}  [✗] Este script requiere sudo.${C_RST}\n"
    printf "      Ejecuta: ${C_BOLD}sudo bash %s${C_RST}\n\n" "$0"
    exit 1
  fi
}

# =============================================================================
# get_macos_version / get_arch / get_current_user
# =============================================================================
get_macos_version() { sw_vers -productVersion 2>/dev/null || echo "unknown"; }
get_arch()          { uname -m 2>/dev/null || echo "unknown"; }
get_current_user()  {
  if [ -n "${SUDO_USER:-}" ]; then echo "$SUDO_USER"
  else whoami; fi
}

# =============================================================================
# sep — línea divisoria en consola
# =============================================================================
sep() {
  printf "  ${C_GRAY}──────────────────────────────────────────────────${C_RST}\n"
}

# =============================================================================
# banner — pantalla de bienvenida
# =============================================================================
banner() {
  clear
  printf "\n"
  printf "  ${C_BCYAN}==================================================${C_RST}\n"
  printf "  ${C_BCYAN}  PGDiagnostic${C_RST}\n"
  printf "  ${C_GRAY}  %s${C_RST}\n" "$PGDIAG_ORG"
  printf "  ${C_GRAY}  Version %s${C_RST}\n" "$PGDIAG_VERSION"
  printf "  ${C_BCYAN}==================================================${C_RST}\n"
  printf "\n"
}
