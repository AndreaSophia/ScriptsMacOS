#!/bin/bash
# =============================================================================
# PGDiagnostic — lib/collect_system.sh
# Responsabilidad: recopilar información del sistema operativo y hardware
# =============================================================================

# =============================================================================
# collect_system — Recopila info del sistema y popula variables de contexto
# Retorna: RC_OK
# =============================================================================
collect_system() {
  log "STEP" "Información del sistema"
  tl "Sistema"

  local outfile="${EVIDENCE_DIR}/sistema/system_info.txt"

  {
    printf '# ======================================================\n'
    printf '# INFORMACIÓN DEL SISTEMA\n'
    printf '# Generado: %s\n' "$(date '+%Y-%m-%d %H:%M:%S')"
    printf '# ======================================================\n\n'
  } > "$outfile"

  # --- macOS ---
  run_collect "Versión macOS (sw_vers)" "$outfile" sw_vers

  # --- Hardware ---
  run_collect "Hardware (system_profiler)" "$outfile" \
    system_profiler SPHardwareDataType

  # --- Kernel ---
  run_collect "Kernel (uname -a)" "$outfile" uname -a

  # --- CPU ---
  {
    printf '# CPU\n# ---\n'
    sysctl -n machdep.cpu.brand_string 2>/dev/null || \
      sysctl -n hw.model 2>/dev/null || echo "N/A"
    printf '\n'
  } >> "$outfile"

  # --- Memoria ---
  {
    printf '# Memoria RAM\n# ---\n'
    local mem_bytes
    mem_bytes="$(sysctl -n hw.memsize 2>/dev/null || echo 0)"
    printf '%d GB\n\n' "$((mem_bytes / 1024 / 1024 / 1024))"
  } >> "$outfile"

  # --- Disco ---
  run_collect "Espacio en disco" "$outfile" df -h /

  # --- Uptime ---
  run_collect "Uptime" "$outfile" uptime

  # --- Usuario y hostname ---
  run_collect "Nombre del equipo" "$outfile" scutil --get ComputerName

  {
    printf '# Usuarios\n# ---\n'
    stat -f '%Su' /dev/console 2>/dev/null
    who 2>/dev/null
    printf '\n'
  } >> "$outfile"

  # --- FileVault ---
  {
    printf '# FileVault\n# ---\n'
    fdesetup status 2>/dev/null || echo "N/A"
    printf '\n'
  } >> "$outfile"

  # --- SIP ---
  {
    printf '# SIP (System Integrity Protection)\n# ---\n'
    csrutil status 2>/dev/null || echo "N/A"
    printf '\n'
  } >> "$outfile"

  # --- Poblar contexto ---
  CTX_MACOS_VER="$(sw_vers -productVersion 2>/dev/null || echo 'N/A')"
  CTX_ARCH="$(uname -m 2>/dev/null || echo 'N/A')"
  CTX_CURRENT_USER="$(get_current_user)"

  # Nombre del equipo: preferir scutil, fallback a hostname
  CTX_HOSTNAME_DISPLAY="$(scutil --get ComputerName 2>/dev/null || \
    hostname 2>/dev/null || echo 'N/A')"

  # Modelo: system_profiler puede tardar — usar sysctl como alternativa rápida
  # en Apple Silicon; grep con awk para manejar espacios variables
  CTX_MAC_MODEL="$(system_profiler SPHardwareDataType 2>/dev/null | \
    awk -F': ' '/Model Name/{gsub(/^[[:space:]]+/,"",$2); print $2; exit}')"
  if [ -z "$CTX_MAC_MODEL" ]; then
    # Fallback para VMs o equipos donde system_profiler falla
    CTX_MAC_MODEL="$(sysctl -n hw.model 2>/dev/null || echo 'N/A')"
  fi

  local fv_status sip_status
  fv_status="$(fdesetup status 2>/dev/null)"
  sip_status="$(csrutil status 2>/dev/null)"

  log "OK" "Sistema: macOS ${CTX_MACOS_VER} | ${CTX_ARCH} | ${CTX_MAC_MODEL}"
  record "Sistema" "$RC_OK" "macOS ${CTX_MACOS_VER} (${CTX_ARCH})"

  if echo "$fv_status" | grep -qi "On"; then
    record "FileVault" "$RC_OK" "Habilitado"
  else
    record "FileVault" "$RC_WARN" "No habilitado"
  fi

  if echo "$sip_status" | grep -qi "enabled"; then
    record "SIP" "$RC_OK" "Habilitado"
  else
    record "SIP" "$RC_WARN" "Deshabilitado"
  fi

  return $RC_OK
}
